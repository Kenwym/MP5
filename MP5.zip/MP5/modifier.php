
<!doctype html>
<html>
<head>
  <title>
   PHP EXO 5
  </title>
  <meta charset="utf-8"/>
 </head>
 <body>
 <h1> Voici le résultat de votre requete : </h1>
 <h2><a href="modifier.html">Modifier</a></h2>
 <?php
 $first = true;
 $obj_of_req = "";

 if (isset($_POST['nom'])) {
     if ($_POST['nom'] != ""){
         if ($first) {
             $temp = $_POST['nom'];
             $obj_of_req .= " WHERE nom=\"$temp\" ";
             $first = false;
         }
     }
 }
 if (isset($_POST['prenom'])) {
     if ($_POST['prenom'] != ""){
         if ($first) {
             $temp = $_POST['prenom'];
             $obj_of_req .= " WHERE prenom=\"$temp\" ";
             $first = false;
         }
         else {
             $temp = $_POST['prenom'];
             $obj_of_req .= " AND prenom=\"$temp\" ";
         }
     }
 }
 if (isset($_POST['telephone'])) {
     if ($_POST['telephone'] != ""){
         if ($first) {
             $temp = $_POST['telephone'];
             $obj_of_req .= " WHERE telephone=\"$temp\" ";
             $first = false;
         }
         else {
             $temp = $_POST['telephone'];
             $obj_of_req .= " AND telephone=\"$temp\" ";
         }
     }
 }
 if (isset($_POST['mail'])) {
     if ($_POST['mail'] != ""){
         if ($first) {
             $temp = $_POST['mail'];
             $obj_of_req .= " WHERE email=\"$temp\" ";
             $first = false;
         }
         else {
             $temp = $_POST['mail'];
             $obj_of_req .= " AND email=\"$temp\" ";
         }
     }
 }
 if (isset($_POST['qualite'])) {
     if ($_POST['qualite'] != ""){
         if ($first) {
             $temp = $_POST['qualite'];
             $obj_of_req .= " WHERE qualite=\"$temp\" ";
             $first = false;
         }
         else {
             $temp = $_POST['qualite'];
             $obj_of_req .= " AND qualite=\"$temp\" ";
         }
     }
 }

 try
 {
     $bdd = new PDO('mysql:host=localhost;dbname=mp4;charset=utf8', 'root', '');
     if(isset($_POST['modifier'])) {
         $first_c = true;
         $obj_of_req_c = "";

         if (isset($_POST['nom1'])) {
             if ($_POST['nom1'] != ""){
                 if ($first_c) {
                     $temp_c = $_POST['nom1'];
                     $obj_of_req_c .= " SET nom=\"$temp_c\" ";
                     $first_c = false;
                 }
             }
         }
         if (isset($_POST['prenom1'])) {
             if ($_POST['prenom1'] != ""){
                 if ($first_c) {
                     $temp_c = $_POST['prenom1'];
                     $obj_of_req_c .= " SET prenom=\"$temp_c\" ";
                     $first_c = false;
                 }
                 else {
                     $temp_c = $_POST['prenom1'];
                     $obj_of_req_c .= " ,  prenom=\"$temp_c\" ";
                 }
             }
         }
         if (isset($_POST['telephone1'])) {
             if ($_POST['telephone1'] != ""){
                 if ($first_c) {
                     $temp_c = $_POST['telephone1'];
                     $obj_of_req_c .= " SET telephone=\"$temp_c\" ";
                     $first_c = false;
                 }
                 else {
                     $temp_c = $_POST['telephone1'];
                     $obj_of_req_c .= " ,  telephone=\"$temp_c\" ";
                 }
             }
         }
         if (isset($_POST['email1'])) {
             if ($_POST['email1'] != ""){
                 if ($first_c) {
                     $temp_c = $_POST['email1'];
                     $obj_of_req_c .= " SET email=\"$temp_c\" ";
                     $first_c = false;
                 }
                 else {
                     $temp_c = $_POST['email1'];
                     $obj_of_req_c .= " ,  email=\"$temp_c\" ";
                 }
             }
         }
         if (isset($_POST['qualite1'])) {
             if ($_POST['qualite1'] != ""){
                 if ($first_c) {
                     $temp_c = $_POST['qualite1'];
                     $obj_of_req_c .= " SET qualite=\"$temp_c\" ";
                     $first_c = false;
                 }
                 else {
                     $temp_c = $_POST['qualite1'];
                     $obj_of_req_c .= " ,  qualite=\"$temp_c\" ";
                 }
             }
         }
         if ($obj_of_req != "") {
             $bdd->query("UPDATE contact$obj_of_req_c$obj_of_req;");
         }
     }
     
 }
 catch(Exception $e)
 {
         die('Erreur : '.$e->getMessage());
 }
?>
</body>
</html>