
<!doctype html>
<html>
<head>
  <title>
   PHP EXO 5
  </title>
  <meta charset="utf-8"/>
 </head>
 <body>
 <h1> Voici le résultat de votre requete : </h1>
 <h2><a href="supprimer.html">Supprimer</a></h2>
 <?php
$first = true;
$obj_of_req = "";
if (isset($_POST['supprimer'])){
if (isset($_POST['nom'])) {
    if ($_POST['nom'] != ""){
        if ($first) {
            $temp = $_POST['nom'];
            $obj_of_req .= " WHERE nom=\"$temp\" ";
            $first = false;
        }
    }
}
if (isset($_POST['prenom'])) {
    if ($_POST['prenom'] != ""){
        if ($first) {
            $temp = $_POST['prenom'];
            $obj_of_req .= " WHERE prenom=\"$temp\" ";
            $first = false;
        }
        else {
            $temp = $_POST['prenom'];
            $obj_of_req .= " AND prenom=\"$temp\" ";
        }
    }
}
if (isset($_POST['telephone'])) {
    if ($_POST['telephone'] != ""){
        if ($first) {
            $temp = $_POST['telephone'];
            $obj_of_req .= " WHERE telephone=\"$temp\" ";
            $first = false;
        }
        else {
            $temp = $_POST['telephone'];
            $obj_of_req .= " AND telephone=\"$temp\" ";
        }
    }
}
if (isset($_POST['email'])) {
    if ($_POST['email'] != ""){
        if ($first) {
            $temp = $_POST['email'];
            $obj_of_req .= " WHERE email=\"$temp\" ";
            $first = false;
        }
        else {
            $temp = $_POST['email'];
            $obj_of_req .= " AND email=\"$temp\" ";
        }
    }
}
if (isset($_POST['qualite'])) {
    if ($_POST['qualite'] != ""){
        if ($first) {
            $temp = $_POST['qualite'];
            $obj_of_req .= " WHERE qualite=\"$temp\" ";
            $first = false;
        }
        else {
            $temp = $_POST['qualite'];
            $obj_of_req .= " AND qualite=\"$temp\" ";
        }
    }
}

try
{
  
  $bdd = new PDO('mysql:host=localhost;dbname=mp4;charset=utf8', 'root', '');
  if ($obj_of_req != "") {
    $reponse = $bdd->query("DELETE FROM contact$obj_of_req;");
  }
  
}
catch(Exception $e)
{
        die('Erreur : '.$e->getMessage());
}
}
else{
  if (isset($_POST['nom'])) {
    if ($_POST['nom'] != ""){
        if ($first) {
            $temp = $_POST['nom'];
            $obj_of_req .= " WHERE nom=\"$temp\" ";
            $first = false;
        }
    }
}
if (isset($_POST['prenom'])) {
    if ($_POST['prenom'] != ""){
        if ($first) {
            $temp = $_POST['prenom'];
            $obj_of_req .= " WHERE prenom=\"$temp\" ";
            $first = false;
        }
        else {
            $temp = $_POST['prenom'];
            $obj_of_req .= " AND prenom=\"$temp\" ";
        }
    }
}
if (isset($_POST['telephone'])) {
    if ($_POST['telephone'] != ""){
        if ($first) {
            $temp = $_POST['telephone'];
            $obj_of_req .= " WHERE telephone=\"$temp\" ";
            $first = false;
        }
        else {
            $temp = $_POST['telephone'];
            $obj_of_req .= " AND telephone=\"$temp\" ";
        }
    }
}
if (isset($_POST['email'])) {
    if ($_POST['email'] != ""){
        if ($first) {
            $temp = $_POST['mail'];
            $obj_of_req .= " WHERE email=\"$temp\" ";
            $first = false;
        }
        else {
            $temp = $_POST['mail'];
            $obj_of_req .= " AND email=\"$temp\" ";
        }
    }
}
if (isset($_POST['qualite'])) {
    if ($_POST['qualite'] != ""){
        if ($first) {
            $temp = $_POST['qualite'];
            $obj_of_req .= " WHERE qualite=\"$temp\" ";
            $first = false;
        }
        else {
            $temp = $_POST['qualite'];
            $obj_of_req .= " AND qualite=\"$temp\" ";
        }
    }
}

try
{

    $bdd = new PDO('mysql:host=localhost;dbname=mp4;charset=utf8', 'root', '');
    $reponse = $bdd->query("SELECT * FROM contact$obj_of_req;");
    while ($donnees = $reponse->fetch())
    {
        $nom = $donnees['nom'];
        $prenom = $donnees['prenom'];
        $telephone = $donnees['telephone'];
        $mail = $donnees['email'];
        $qualite = $donnees['qualite'];
        echo "$nom $prenom | $telephone | $mail | $qualite <br>";
    }
    $reponse->closeCursor();
    
}
catch(Exception $e)
{
        die('Erreur : '.$e->getMessage());
}
}

?>
</body>